<?php

return [
    'site_title' => 'Support Ticketing',
];
